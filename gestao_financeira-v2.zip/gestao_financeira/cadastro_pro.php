
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Cadastro Pro · Caishen</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/checkout/">

    <!-- Bootstrap core CSS -->
<link href="docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">

  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <div class="container">
        <a class="navbar-brand" href="index.php">Caishen</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="cadastro_gratis.php">Grátis</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cadastro_enterprise.php">Enterprise</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="cadastro_pro.php">Pro</a>
            </li>
            </ul>
            <a class="btn btn-outline-light" href="login.php">Entrar</a>
        </div>
        </div>
    </nav>

    <div class="container">
  <div class="py-5 text-center">
    <img class="d-block mx-auto mb-4" src="/docs/4.3/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
    <h2>Cadastro</h2>
    <p class="lead">Você está prestes a se registrar em nossos serviços, está fazendo uma ótima escolha.</p>
  </div>

  <div class="row">
    <div class="col-md-4 order-md-2 mb-4">
      <h4 class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted">Seu carrinho</span>
        <span class="badge badge-dark badge-pill">1</span>
      </h4>
      <ul class="list-group mb-3">
        <li class="list-group-item d-flex justify-content-between lh-condensed">
          <div>
            <h6 class="my-0">Caishen Pro</h6>
            <small class="text-muted">Acesso ilimitado ao DashBoard do Caishen, suporte e muito mais.</small>
          </div>
          <span class="text-muted">R$15</span>
        </li>
        <li class="list-group-item d-flex justify-content-between">
          <span>Total (R$)</span>
          <strong>R$15</strong>
        </li>
      </ul>

      <form class="card p-2">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Código de Promoção">
          <div class="input-group-append">
            <button type="submit" class="btn btn-dark">Resgatar</button>
          </div>
        </div>
      </form>
    </div>
    <div class="col-md-8 order-md-1">
      
    <form class="needs-validation" action="cadastro_pro.php" method="post" novalidate>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="firstName">Primeiro Nome</label>
                <input type="text" class="form-control" id="firstName" placeholder="" value="" name="primeiroNome" required>
                <div class="invalid-feedback">
                Primeiro nome necessário
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <label for="lastName">Último Nome</label>
                <input type="text" class="form-control" id="lastName" placeholder="" value="" name="ultimoNome" required>
                <div class="invalid-feedback">
                Último nome necessário
                </div>
            </div>
            </div>

            <div class="mb-3">
            <label for="username">Nome de Usuário</label>
            <div class="input-group">
                <div class="input-group-prepend">
                <span class="input-group-text">@</span>
                </div>
                <input type="text" class="form-control" id="username" placeholder="Nome de Usuário" name="nomeUsuario" required>
                <div class="invalid-feedback" style="width: 100%;">
                Seu nome de usuário é necessário
                </div>
            </div>
            </div>

            <div class="mb-3">
            <label for="email">Email </label>
            <input type="email" class="form-control" id="email" placeholder="você@exemplo.com" name="email" required>
            <div class="invalid-feedback">
                Por favor entre um email válido para mantermos você atualizado
            </div>
            </div>

            <div class="mb-3">
            <label for="password">Senha</label>
            <input type="password" class="form-control" id="password" placeholder="" name="senha" required>
            <div class="invalid-feedback">
                Por favor a senha é necessária
            </div>
            </div>

            <div class="mb-3">
            <label for="confirm-password">Confirmar Senha</label>
            <input type="password" class="form-control" id="confirm-password" placeholder="" name="confirmaSenha" required>
            <div class="invalid-feedback">
                Por favor a confirmação da senha é necessária
            </div>
            </div>

            <div class="mb-3">
            <label for="address">Endereço</label>
            <input type="text" class="form-control" id="address" placeholder="Av. Paulista, 1020" name="endereco" required>
            <div class="invalid-feedback">
                Por favor entre um endereço válido
            </div>
            </div>

            <div class="row">
            <div class="col-md-5 mb-3">
                <label for="country">País</label>
                <select class="custom-select d-block w-100" id="country" name="pais" required>
                <option value="">Escolha...</option>
                <option>Brasil</option>
                </select>
                <div class="invalid-feedback">
                Por favor selecione um país válido
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <label for="state">Estado</label>
                <select class="custom-select d-block w-100" id="state" name="estado" required>
                <option value="">Escolha...</option>
                <option>São Paulo</option>
                <option>Rio de Janeiro</option>
                </select>
                <div class="invalid-feedback">
                Por favor selecione um Estado Válido
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <label for="zip">CEP</label>
                <input type="text" class="form-control" id="zip" placeholder="09141-876" name="cep" required>
                <div class="invalid-feedback">
                CEP necessário
                </div>
            </div>
        </div>

        <hr class="mb-4">

        <h4 class="mb-3">Pagamento</h4>

        <div class="d-block my-3">
        <div class="custom-control custom-radio">
            <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
            <label class="custom-control-label" for="credit">Cartão de crédito</label>
        </div>
        </div>
        <div class="row">
        <div class="col-md-6 mb-3">
            <label for="cc-name">Nome no cartão</label>
            <input type="text" class="form-control" id="cc-name" placeholder="" name="nomeCC" required>
            <small class="text-muted">Nome completo como exibido no cartão</small>
            <div class="invalid-feedback">
            O nome do cartão é necessário
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <label for="cc-number">Número do cartão de crédito</label>
            <input type="text" class="form-control" id="cc-number" placeholder="" name="numeroCC" required>
            <div class="invalid-feedback">
            O número do cartão de crédito é necessário
            </div>
        </div>
        </div>
        <div class="row">
        <div class="col-md-3 mb-3">
            <label for="cc-expiration">Expiração</label>
            <input type="text" class="form-control" id="cc-expiration" placeholder="" name="expiracaoCC" required>
            <div class="invalid-feedback">
            A data de expiração é necessária
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <label for="cc-cvv">CVV</label>
            <input type="text" class="form-control" id="cc-cvv" placeholder="" name="cvvCC" required>
            <div class="invalid-feedback">
            O código de segurança é necessário
            </div>
        </div>
        </div>

        <hr class="mb-4">

        <div class="custom-control custom-checkbox mb-4"> 
        <input type="checkbox" class="custom-control-input" id="Termos-uso">
        <label class="custom-control-label" for="Termos-uso">Aceitar Termos de Uso e Privacidade</label>
        </div>

        <button class="btn btn-dark btn-lg btn-block" type="submit" name="btn">Próximo</button>

        <?php
        
          require("controllers/validaCadastros.php");
          $validador = new Cadastro;

          if(isset($_POST['btn']))
          {
            $primeiroNome = $_POST['primeiroNome'];
            $ultimoNome = $_POST['ultimoNome'];
            $nomeUsuario = $_POST['nomeUsuario'];
            $email = $_POST['email'];
            $senha = $_POST['senha'];

            if($_POST['confirmaSenha'] == $senha)
            {
              $endereco = $_POST['endereco'];
              $pais = $_POST['pais'];
              $estado = $_POST['estado'];
              $cep = $_POST['cep'];
              $nomeCartao = $_POST['nomeCC'];
              $numeroCartao = $_POST['numeroCC'];
              $expiracao = $_POST['expiracaoCC'];
              $cvv = $_POST['cvvCC'];
            
              $validador->cadastraPro($primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$estado,$cep,$nomeCartao,$numeroCartao,$expiracao,$cvv);
            }
            else
            {
              echo "<h3 class='alert-danger'>As senhas não são iguais</h3>";
            }
          }

          ?>
      </form>
    </div>
  </div>

          <footer class="my-5 pt-5 text-muted text-center text-small">
            <p class="mb-1">&copy; 2017-2019 Caishen</p>
            <ul class="list-inline">
              <li class="list-inline-item"><a href="#">Privacidade</a></li>
              <li class="list-inline-item"><a href="#">Termos</a></li>
              <li class="list-inline-item"><a href="#">Ajuda</a></li>
            </ul>
          </footer>
        </div>
        <script src="docs/4.3/assets/js/vendor/jquery-slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script>window.jQuery || document.write('<script src="docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
        <script src="bootstrap/dist/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
    </body>
</html>
