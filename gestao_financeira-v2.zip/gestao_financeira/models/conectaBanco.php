<?php

    class Dados
    {
        public $con;
        private $usuarioSessao;
        private $sessao;

        public function ConectaBanco()
        {
            $this->con = mysqli_connect("localhost:3307","root","","db_caishen") or die ("<script>window.alert('Erro na conexão');</script>");
        }

        public function cadastraUsuarioGratuito($primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$precoServico, $tipoPagamento)
        {
            $dados = new Dados;
            $this->ConectaBanco();
            
            $verificaEmail = mysqli_query($this->con, "SELECT * from tb_cadastro where email = '$email'");

            if(mysqli_fetch_assoc($verificaEmail))
            {
                echo "<h3 class='alert-danger'>Não pode cadastrar esse email.</h3>";
            }
            else
            {
                if($query = mysqli_query($this->con,"INSERT INTO tb_cadastro(primeiroNome,ultimoNome,nomeUsuario,email,senha,endereco,pais,estado,cep,tipoPagamento,nomeCartao,numeroCartao,expiracao,cvv,precoServico)
                VALUES('$primeiroNome','$ultimoNome','$nomeUsuario','$email','$senha','$endereco','$pais','$uf','$cep','$tipoPagamento',null,null,null,null,'$precoServico')"))
                {
                    $subject = "Confirmação de cadastro - Caishen";
                    $mensagem = "Olá $primeiroNome aqui é o Vitor da Caishen, esperamos que você tenha uma ótima experiência, você pode ter nosso suporte a hora que precisar se cadastrando como cliente Enterprise ou Pro no nosso site. Agradecemos pela sua preferência! <br><br>Atenciosamente Vitor de Souza da Caishen";

                    $headers .= "To: $primeiroNome <$email>" . "\r\n";
                    $headers .= "From: Vitor da Caishen <vitorsantos@caishen.com>" . "\r\n";
                    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

                    mail($email, $subject, $mensagem,$headers);

                    echo 
                    "
                        <script>
                            window.alert('Sucesso no cadastro, agora entre!');
                            window.location.href = 'login.php';
                        </script>
                    ";
                }
            }
            
            mysqli_close($this->con);
        }

        public function cadastraUsuarioPago($primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$nomeCartao,$numeroCartao,$expiracao,$cvv,$precoServico, $tipoPagamento)
        {
            $dados = new Dados;
            $this->ConectaBanco();

            $verificaEmail = mysqli_query($this->con, "SELECT * from tb_cadastro where email = '$email'");

            if(mysqli_fetch_assoc($verificaEmail))
            {
                echo "<h3 class='alert-danger'>Não pode cadastrar esse email.</h3>";
            }
            else
            {
                if($query = mysqli_query($this->con,"INSERT INTO tb_cadastro(primeiroNome,ultimoNome,nomeUsuario,email,senha,endereco,pais,estado,cep,tipoPagamento,nomeCartao,numeroCartao,expiracao,cvv,precoServico)
                VALUES('$primeiroNome','$ultimoNome','$nomeUsuario','$email','$senha','$endereco','$pais','$uf','$cep','$tipoPagamento','$nomeCartao','$numeroCartao','$expiracao','$cvv','$precoServico')"))
                {

                    $subject = "Confirmação de cadastro - Caishen";
                    $mensagem = "Olá $primeiroNome aqui é o Vitor da Caishen, esperamos que você tenha uma ótima experiência, você pode ter nosso suporte a hora que precisar se cadastrando como cliente Enterprise ou Pro no nosso site. Agradecemos pela sua preferência! <br><br>Atenciosamente Vitor de Souza da Caishen";

                    $headers .= "To: $primeiroNome <$email>" . "\r\n";
                    $headers .= "From: Vitor da Caishen <vitorsantos@caishen.com>" . "\r\n";
                    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

                    echo 
                    "
                        <script>
                            window.alert('Sucesso no cadastro, agora entre!');
                            window.location.href = 'login.php';
                        </script>
                    ";
                }
            }

            mysqli_close($this->con);
        }

        public function Entrar($email,$senha)
        {
            $dados = new Dados;
            $dados->ConectaBanco();

            $selecionarLogin = mysqli_query($dados->con, "SELECT * FROM tb_cadastro where email = '$email' and senha = '$senha'");

            if($infos = mysqli_fetch_assoc($selecionarLogin))
            {
                $usuario = $infos['nomeUsuario'];

                $this->setUsuario($usuario);

            }
            else
            {
                echo "<h4 class='alert-danger'>Email ou senha errado</h4>";
            }

            mysqli_close($dados->con);
        }

        public function setUsuario($usuario)
        {
            $this->usuarioSessao = $usuario;

            session_start();

            $_SESSION["logado"] = $this->usuarioSessao;
            header('Location:dash.php');
   
        }

        public function validaUsuario()
        {
            if($this->usuarioSessao == $this->sessao)
            {
                echo "Logado como ".$this->usuarioSessao;
            }
            else
            {
                echo "<script>window.location.href = 'index.php';</script>";
            }
        }

        /*
        public function verificaLogin()
        {

        }
        */

    }

?>