<?php
    
    require("models/conectaBanco.php");
    
    class Cadastro
    {
        public function cadastraGratuito($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce)
        {
            $cadastroDados = new Dados;

            //codigo para validar cadastro gratuito passando os parametros pela função cadastraGratuito
            $precoServico = "0";
            $tipoPagamento = "Gratuito";

            $cadastroDados->cadastraUsuarioGratuito($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce,$precoServico,$tipoPagamento);
                                            //$primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$precoServico, $tipoPagamento
        }

        public function cadastraEnterprise($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce, $nomeCartao,$numeroCartao,$expiracao,$cvv)
        {
            $cadastroDados = new Dados;

            //codigo para validar cadastro gratuito passando os parametros pela função cadastraEnterprise
            $precoServico = "29";
            $tipoPagamento = "Cartão de Crédito";

            $cadastroDados->cadastraUsuarioPago($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce,$nomeCartao, $numeroCartao,$expiracao,$cvv,$precoServico,$tipoPagamento);
            //      $primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$nomeCartao,$numeroCartao,$expiracao,$cvv,$precoServico, $tipoPagamento
        }

        public function cadastraPro($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce,$nomeCartao,$numeroCartao,$expiracao,$cvv)
        {
            $cadastroDados = new Dados;

            //codigo para validar cadastro gratuito passando os parametros pela função cadastraPro
            $precoServico = "15";
            $tipoPagamento = "Cartão de Crédito";

            $cadastroDados->cadastraUsuarioPago($pNome,$uNome,$nomeUse,$ema,$pass,$end,$coutry,$uf,$ce,$nomeCartao, $numeroCartao,$expiracao,$cvv,$precoServico,$tipoPagamento);
        }
    }
?>