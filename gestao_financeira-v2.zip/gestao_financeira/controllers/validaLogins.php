<?php
    
    require("models/conectaBanco.php");
    $dados = new Dados;

    $dados->Entrar($email, $senha);
?>  