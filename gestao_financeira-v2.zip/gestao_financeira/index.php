<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Home · Caishen</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link href="docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
          .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
          }

          @media (min-width: 768px) {
            .bd-placeholder-img-lg {
              font-size: 3.5rem;
            }
          }
        </style>
        <!-- Custom styles for this template -->
        <link href="pricing.css" rel="stylesheet">
      </head>
      <body>
        
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
          <div class="container">
            <a class="navbar-brand" href="index.php">Caishen</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="#Precos">Preços</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Caracteristicas">Caracteristicas</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#TeamCaishen">Team Caishen</a>
                </li>
              </ul>
              <a class="btn btn-outline-light" href="login.php">Entrar</a>
            </div>
          </div>
        </nav>

        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center mt-5" id="Precos">
          <h1 class="display-4">Preços</h1>
          <p class="lead">Invista no seu dinheiro. Você no controle do seu dinheiro.</p>
        </div>

        <div class="container">
          <div class="card-deck mb-3 text-center">
            <div class="card mb-4 shadow-sm mt-5">
              <div class="card-header bg-dark text-light">
                <h4 class="my-0 font-weight-normal">Grátis</h4>
              </div>
              <div class="card-body">
                <h1 class="card-title pricing-card-title">R$0 <small class="text-muted">/ Mês</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                  <li>+ Modo consumidor compulsivo</li>
                  <li>+ Inserção de despesas limitadas</li>
                </ul>
                <button type="button" class="btn btn-lg btn-block btn-outline-dark" onclick="window.location.href = 'cadastro_gratis.php'">Cadastre-se de graça</button>
              </div>
            </div>
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-primary text-light">
                <h4 class="my-0 font-weight-normal">Enterprise</h4>
              </div>
              <div class="card-body">
                <h1 class="card-title pricing-card-title">R$29 <small class="text-muted">/ Mês</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                  <li></li>
                  <li>+ Administre seus gastos</li>
                  <li>+ Planejamento a longo prazo</li>
                  <li>+ Suporte da plataforma</li>
                  <li>+ Acesso a todas as ferramentas</li>
                  <li>+ Modelos Econômicos</li>
                  <li>+ Sem Anuncios</li>
                </ul>
                <button type="button" class="btn btn-lg btn-block btn-primary" onclick="window.location.href = 'cadastro_enterprise.php'">Não Perca Tempo</button>
              </div>
            </div>
            <div class="card mb-4 shadow-sm mt-5">
              <div class="card-header bg-dark text-light">
                <h4 class="my-0 font-weight-normal">Pro</h4>
              </div>
              <div class="card-body">
                <h1 class="card-title pricing-card-title">R$15 <small class="text-muted">/ Mês</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                  <li>+ Administre seus gastos</li>
                  <li>+ Planejamento a longo prazo</li>
                  <li>+ Suporte da plataforma</li>
                </ul>
                <button type="button" class="btn btn-lg btn-block btn-outline-dark" onclick="window.location.href = 'cadastro_pro.php'">Comece Agora</button>
              </div>
            </div>
          </div>

          <!-- START THE FEATURETTES -->

          <hr class="featurette-divider" id="Caracteristicas">

          <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
              <h2 class="display-4">Caracteristicas</h2>
          </div>

          <div class="row featurette">
            <div class="col-md-7">
              <h2 class="featurette-heading">Um pouco sobre o Caishen <span class="text-muted">O tempo é precioso</span></h2>
              <p class="lead">Caishen é uma solução para você que não consegue controlar suas finanças, você poderá simular meses futuros, analisando se estará no vermelho ou não, sem contar de modelos para que suas finanças pessoais fiquem boas. Nós te auxiliamos a ter uma vida melhor.</p>
            </div>
            <div class="col-md-5">
              <img class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" src="img/gestao.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 500x500"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/></img>
            </div>
          </div>

          <hr class="featurette-divider" id="TeamCaishen">

          <!-- Three columns of text below the carousel -->
          <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
              <h2 class="display-4">Team Caishen</h2>
          </div>
          <div class="row">
            <div class="col-lg-4">
              <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="img/andre.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/></img>
              <h2>Andre Franca</h2>
              <p>Adoro plantar batata no tempo livre, programar e achar Bugs no programa dos outros.</p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="img/pedro.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/></img>
              <h2>Pedro Duarte</h2>
              <p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh.</p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="img/vitor.jpeg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/></img>
              <h2>Vitor de Souza</h2>
              <p>Gosto de programar e trazer soluções, mas também gosto da natureza, fazer trilhas e ir para cachoeiras. Espero que o Caishen seja de grande importância para você assim como é para nós.</p>
            </div><!-- /.col-lg-4 -->
          </div><!-- /.row -->

          <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
              <div class="col-12 col-md">
                <!--img class="mb-2" src="docs/4.3/assets/brand/bootstrap-solid.svg" alt="" width="24" height="24"-->
                <small class="d-block mb-3 text-muted">&copy; 2017-2019</small>
              </div>

              <div class="col-6 col-md">
                <h5>Preços</h5>
                <ul class="list-unstyled text-small">
                  <li><a class="text-muted" href="cadastro_gratis.php">Gratuito</a></li>
                  <li><a class="text-muted" href="cadastro_enterprise.php">Enterprise</a></li>
                  <li><a class="text-muted" href="cadastro_pro.php">Pro</a></li>
                </ul>
              </div>
              <div class="col-6 col-md">
                <h5>Caracteristicas</h5>
                <ul class="list-unstyled text-small">
                  <li><a class="text-muted" href="#Caracteristicas">Calculo de Despesas Mensais</a></li>
                  <li><a class="text-muted" href="#Caracteristicas">Calculo de Rentabilidade</a></li>
                  <li><a class="text-muted" href="#Caracteristicas">Despesas de cartões</a></li>
                </ul>
              </div>
              <div class="col-6 col-md">
                <h5>Sobre</h5>
                <ul class="list-unstyled text-small">
                  <li><a class="text-muted" href="#TeamCaishen">Team Caishen</a></li>
                </ul>
              </div>
            </div>
          </footer>
        </div>

        <script src="docs/4.3/assets/js/vendor/jquery-slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script>window.jQuery || document.write('<script src="docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
        <script src="bootstrap/dist/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>

    </body>
</html>
