create database db_caishen;
use db_caishen;

create table tb_cadastro(
	id_cadastro int not null auto_increment primary key,
    primeiroNome varchar(100) not null,
    ultimoNome varchar(100) not null,
    nomeUsuario varchar(100) not null,
    email varchar(100) not null,
    senha varchar(100) not null,
    endereco varchar(500) not null,
    pais varchar(100) not null,
    estado varchar(100) not null,
    cep varchar(50) not null,
    tipoPagamento varchar(100) not null,
    nomeCartao varchar(200),
    numeroCartao varchar(200),
    expiracao varchar(50),
    cvv varchar(50),
    precoServico varchar(20)
);

INSERT INTO tb_cadastro(primeiroNome,ultimoNome,nomeUsuario,email,senha,endereco,pais,estado,cep,tipoPagamento,nomeCartao,numeroCartao,expiracao,cvv,precoServico)
            VALUES('$primeiroNome','$ultimoNome','$nomeUsuario','$email','$senha','$endereco','$pais','$uf','$cep','$tipoPagamento',null,null,null,null,'$precoServico');

SELECT * FROM tb_cadastro;

drop database db_caishen;