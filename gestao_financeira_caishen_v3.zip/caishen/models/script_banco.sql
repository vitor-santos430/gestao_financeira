create database db_caishen;
use db_caishen;

create table tb_cadastro(
	id_cadastro int not null auto_increment primary key,
    primeiroNome varchar(100) not null,
    ultimoNome varchar(100) not null,
    nomeUsuario varchar(100) not null,
    email varchar(100) not null,
    senha varchar(100) not null,
    endereco varchar(500) not null,
    pais varchar(100) not null,
    estado varchar(100) not null,
    cep varchar(50) not null,
    tipoPagamento varchar(100) not null,
    nomeCartao varchar(200),
    numeroCartao varchar(200),
    expiracao varchar(50),
    cvv varchar(50),
    precoServico varchar(20)
);

create table tb_despesas(
	id_despesa int not null primary key auto_increment,
	nm_despesa varchar(50) not null,
	valor_despesa decimal not null,
	data_despesa date not null,
    id_cadastro int not null,
    
    constraint usuario_da_despesa
	foreign key(id_cadastro)
	references tb_cadastro(id_cadastro)
);


create table tb_receita(
	id_receita int not null primary key auto_increment,
	nm_receita varchar(50) not null,
	valor_receita decimal not null,
	data_receita date not null,
    id_cadastro int not null,
    
    constraint usuario_da_receita
	foreign key(id_cadastro)
	references tb_cadastro(id_cadastro)
);

INSERT INTO tb_receita(nm_receita,valor_receita,data_receita,id_cadastro) VALUES ('Comissão',2000,'2019-11-20',1);

select * from tb_despesas;

select primeiroNome as "Nome Usuario", date_format(r.data_receita, '%d/%m/%Y') as "Data", nm_receita as "Fonte", concat("R$", valor_receita) as "Valor" from tb_receita r
	inner join tb_cadastro c on c.id_cadastro = r.id_cadastro;

drop database db_caishen;