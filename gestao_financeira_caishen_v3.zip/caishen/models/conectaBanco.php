<?php

    class Dados
    {
        public $con;
        public $emailInsert;
        private $usuarioSessao;
        public $id;
        private $sessao;

        public function ConectaBanco()
        {
            $this->con = mysqli_connect("localhost:3307","root","","db_caishen") or die ("<script>window.alert('Erro na conexão');</script>");
        }

        public function cadastraUsuarioGratuito($primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$precoServico, $tipoPagamento)
        {
            $dados = new Dados;
            $this->ConectaBanco();
            
            $verificaEmail = mysqli_query($this->con, "SELECT * from tb_cadastro where email = '$email'");

            if(mysqli_fetch_assoc($verificaEmail))
            {
                echo "<h3 class='alert-danger'>Não pode cadastrar esse email.</h3>";
            }
            else
            {
                if($query = mysqli_query($this->con,"INSERT INTO tb_cadastro(primeiroNome,ultimoNome,nomeUsuario,email,senha,endereco,pais,estado,cep,tipoPagamento,nomeCartao,numeroCartao,expiracao,cvv,precoServico)
                VALUES('$primeiroNome','$ultimoNome','$nomeUsuario','$email','$senha','$endereco','$pais','$uf','$cep','$tipoPagamento',null,null,null,null,'$precoServico')"))
                {
                    $subject = "Confirmação de cadastro - Caishen";
                    $mensagem = "Olá $primeiroNome aqui é o Vitor da Caishen, esperamos que você tenha uma ótima experiência, você pode ter nosso suporte a hora que precisar se cadastrando como cliente Enterprise ou Pro no nosso site. Agradecemos pela sua preferência! <br><br>Atenciosamente Vitor de Souza da Caishen";

                    $headers .= "To: $primeiroNome <$email>" . "\r\n";
                    $headers .= "From: Vitor da Caishen <vitorsantos@caishen.com>" . "\r\n";
                    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

                    mail($email, $subject, $mensagem,$headers);

                    echo 
                    "
                        <script>
                            window.alert('Sucesso no cadastro, agora entre!');
                            window.location.href = 'login.php';
                        </script>
                    ";
                }
            }
            
            mysqli_close($this->con);
        }

        public function cadastraUsuarioPago($primeiroNome,$ultimoNome,$nomeUsuario,$email,$senha,$endereco,$pais,$uf,$cep,$nomeCartao,$numeroCartao,$expiracao,$cvv,$precoServico, $tipoPagamento)
        {
            $dados = new Dados;
            $this->ConectaBanco();

            $verificaEmail = mysqli_query($this->con, "SELECT * from tb_cadastro where email = '$email'");

            if(mysqli_fetch_assoc($verificaEmail))
            {
                echo "<h3 class='alert-danger'>Não pode cadastrar esse email.</h3>";
            }
            else
            {
                if($query = mysqli_query($this->con,"INSERT INTO tb_cadastro(primeiroNome,ultimoNome,nomeUsuario,email,senha,endereco,pais,estado,cep,tipoPagamento,nomeCartao,numeroCartao,expiracao,cvv,precoServico)
                VALUES('$primeiroNome','$ultimoNome','$nomeUsuario','$email','$senha','$endereco','$pais','$uf','$cep','$tipoPagamento','$nomeCartao','$numeroCartao','$expiracao','$cvv','$precoServico')"))
                {

                    $subject = "Confirmação de cadastro - Caishen";
                    $mensagem = "Olá $primeiroNome aqui é o Vitor da Caishen, esperamos que você tenha uma ótima experiência, você pode ter nosso suporte a hora que precisar se cadastrando como cliente Enterprise ou Pro no nosso site. Agradecemos pela sua preferência! <br><br>Atenciosamente Vitor de Souza da Caishen";

                    $headers .= "To: $primeiroNome <$email>" . "\r\n";
                    $headers .= "From: Vitor da Caishen <vitorsantos@caishen.com>" . "\r\n";
                    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

                    echo 
                    "
                        <script>
                            window.alert('Sucesso no cadastro, agora entre!');
                            window.location.href = 'login.php';
                        </script>
                    ";
                }
            }

            mysqli_close($this->con);
        }

        public function Entrar($email,$senha)
        {
            $dados = new Dados;
            $dados->ConectaBanco();

            $selecionarLogin = mysqli_query($dados->con, "SELECT * FROM tb_cadastro where email = '$email' and senha = '$senha'");

            if($infos = mysqli_fetch_assoc($selecionarLogin))
            {
                $pNomeUsuario = $infos['primeiroNome'];
                $uNomeUsuario = $infos['ultimoNome'];
                $id = $infos['id_cadastro'];
                $this->id = $id;
                $this->setUsuario($pNomeUsuario,$uNomeUsuario,$id);
            }
            else
            {
                echo "<h4 class='alert-danger'>Email ou senha errado</h4>";
            }

            mysqli_close($dados->con);
        }

        public function setUsuario($pNome,$uNome,$id)
        {
            $this->usuarioSessao = $pNome." ".$uNome;
            session_start();

            $_SESSION["logado"] = $this->usuarioSessao;
            $_SESSION["id"] = $id;
            header('Location:dash.php');
   
        }

        /*
        public function Insert_Email()        
        {      
            $dados = new Dados;  
            $email_Inserido = $dados->emailInsert;
            $dados->ConectaBanco();
            $adicionar_Email_da_Despesa['id_cadastro'] = mysqli_query($dados->con, "SELECT id_cadastro FROM tb_cadastro where email = '$email_Inserido'");           
           
            $adicionar_Email_da_Despesa;
            
                                                
        }

        public function Insert_Despesa($Nome_Despesa,$Valor_Despesa,$Data_despesa)
        {
            $dados = new Dados;
            $dados->ConectaBanco();
            $Adicionar_despesa = mysqli_query($dados->con, "SELECT Id_despesa FROM tb_despesas where nm_despesa = '$Nome_Despesa' and valor_despesa = '$Valor_Despesa' and data_despesa = '$Data_despesa'");
            $Adicionar_despesa;
            
        }
        */

        public function cadastraDespesa($nome,$valor,$data)
        {
            $this->ConectaBanco();

            $id = $_SESSION['id'];

            if($insereDespesa = mysqli_query($this->con,"INSERT INTO tb_despesas(nm_despesa,valor_despesa,data_despesa,id_cadastro) VALUES ('$nome',$valor,'$data',$id)"))
            {
                echo "<h4 class='alert-success'>Inserido com sucesso!</h4>";
            }
            else
            {
                echo "<h4 class='alert-danger'>Não inserido!</h4>";
            }

            mysqli_close($this->con);
        }

        public function cadastraReceita($nome,$valor,$data)
        {
            $this->ConectaBanco();

            $id = $_SESSION['id'];
            //echo "<script>alert('$nome  $valor  $data   $teste');</script>";

            if($insereReceita = mysqli_query($this->con,"INSERT INTO tb_receita(nm_receita,valor_receita,data_receita,id_cadastro) VALUES ('$nome',$valor,'$data',$id)"))
            {
                echo "<h4 class='alert-success'>Inserido com sucesso!</h4>";
            }
            else
            {
                echo "<h4 class='alert-danger'>Não inserido!</h4>";
            }

            mysqli_close($this->con);
        }

    }

?>