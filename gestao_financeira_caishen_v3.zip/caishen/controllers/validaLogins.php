<?php
    
    require("models/conectaBanco.php");
    $dados = new Dados;
    
    $dados->emailInsert = $email;

    $dados->Entrar($dados->emailInsert, $senha);
    

?>  