<?php
    // Codigo do Session
    // Serve para verificar se a pessoa esta logada ou se só acessou a página dash.php peça url sem logar
    session_start();
    if((!isset($_SESSION['logado']) == true))
    {
        unset($_SESSION['logado']);
        header('Location: login.php');
    }
    //echo "Logado como ".$_SESSION['logado']; 
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Caishen · Portal Econômico</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/cover/">

    <!-- Bootstrap core CSS -->
<link href="docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="cover.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
 
    </head>
    <body class="text-center">
        <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
    <header class="masthead mb-auto">
        <div class="inner">
        <h3 class="masthead-brand">Caishen</h3>
        <nav class="nav nav-masthead justify-content-center">
            <a class="nav-link" href="dash.php">Adicionar Gastos e Receitas</a>
            <a class="nav-link active" href="grafdash.php">Analisar Situação Pessoal</a>
            <a class="nav-link" href="#">Suporte Financeiro</a>
        </nav>
        </div>
    </header>

    <main role="main" class="inner cover">
        <h1 class="cover-heading"><?php echo "Organizamos para você ".$_SESSION['logado']; ?></h1>
        <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>
    </main>

    <footer class="mastfoot mt-auto">
        <div class="inner">
        <p>Caishen, por @Andre, @Pedro<canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> e @Vitor.</p>
        </div>
    </footer>
    </div>
    <script src="docs/4.3/assets/js/vendor/jquery-slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
    <script src="dashboard.js"></script>
</body>
</html>
