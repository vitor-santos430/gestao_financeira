<?php
    // Codigo do Session
    // Serve para verificar se a pessoa esta logada ou se só acessou a página dash.php peça url sem logar
    session_start();
    if((!isset($_SESSION['logado']) == true))
    {
        unset($_SESSION['logado']);
        header('Location: login.php');
    }
    //echo "Logado como ".$_SESSION['logado']; 
?>

<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Caishen · Portal Econômico</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/cover/">

    <!-- Bootstrap core CSS -->
<link href="docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="cover.css" rel="stylesheet">
  </head>
  <body class="text-center">
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="masthead mb-auto">
    <div class="inner">
      <h3 class="masthead-brand">Caishen</h3>
      <nav class="nav nav-masthead justify-content-center">
        <a class="nav-link active" href="dash.php">Adicionar Gastos e Receitas</a>
        <a class="nav-link" href="grafdash.php">Analisar Situação Pessoal</a>
        <a class="nav-link" href="#">Suporte Financeiro</a>
      </nav>
    </div>
  </header>

  <main role="main" class="inner cover">
    <h1 class="cover-heading"><?php echo "Olá ".$_SESSION['logado']; ?></h1>
    <p class="lead">Adicione na área abaixo os valores de hoje ou de outras datas, seus respectivos nomes, escolha se é um gasto ou receita clicando nos botões abaixo das áreas de preenchimento e iremos organizar tudo para você!</p>
        <form action="dash.php" method="post">
            <p class="lead">
                <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">R$</span>
                </div>
                    <input type="text" class="form-control" aria-label="Amount (to the nearest reais)" placeholder="1000" name="valor">
                </div>
            </p>
            <p class="lead">
                <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Nome valor</span>
                </div>
                    <input type="text" class="form-control" placeholder="Compra do mês" aria-label="nomevalor" aria-describedby="basic-addon1" name="nomeValor">
                </div>
            </p>
            <p class="lead">
                <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Data do valor</span>
                </div>
                    <input type="date" class="form-control" placeholder="05/12/2025" aria-label="datavalor" aria-describedby="basic-addon1" name="dataValor" value="<?php echo date("Y-m-d"); ?>">
                </div>
            </p>
            <p class="lead">
                <button class="btn btn-lg btn-outline-secondary mb-3" name="addReceita">Adicionar Receita</button>
                <button class="btn btn-lg btn-outline-secondary mb-3" name="addGasto">Adicionar Gasto</button>
            </p>
            <?php
                require("models/conectaBanco.php");
                $dados = new Dados;

                if(isset($_POST['addReceita']))
                {
                    $valor = $_POST['valor'];   
                    $nome = $_POST['nomeValor'];
                    $data = $_POST['dataValor'];

                    $dados->cadastraReceita($nome,$valor,$data);
                }
                else if(isset($_POST['addGasto']))
                {
                
                    $valor = $_POST['valor'];   
                    $nome = $_POST['nomeValor'];
                    $data = $_POST['dataValor'];

                    $dados->cadastraDespesa($nome,$valor, $data);
                }

            ?>
        </form>
  </main>

  <footer class="mastfoot mt-auto">
    <div class="inner">
      <p>Caishen, por @Andre, @Pedro e @Vitor.</p>
    </div>
  </footer>
</div>
</body>
</html>
